const ATTRIBUTES = [
    { name: "Benção de Deus", level: 3, element: "Luz" },
    { name: "Tirano", level: 3, element: "Fogo" },
    { name: "Enfraquecer Tirano", level: 3, element: "Gelo" },

    { name: "Redução de Dano de Tropas", level: 3 },
    { name: "Dano de Tropas", level: 3 },
    { name: "Capacidade de Herói", level: 3 },
    { name: "Poder da Unidade", level: 3 },
    { name: "Enfraquecer Supressão", level: 3 },
    { name: "Supressão", level: 3 },
    { name: "Taxa de produção de Primavera", level: 3 },
    { name: "Todo Poder de Gemas De Fogo", level: 3 },
    { name: "Todo Poder de Gemas De Gelo", level: 3 },
    { name: "Todo Poder de Gemas De Veneno", level: 3 },
    { name: "Todo Poder de Gemas De Luz", level: 3 },
    { name: "HADES", level: 3, element: "Veneno" },

    { name: "Guardião", level: 2 },
    { name: "Sede de Sangue", level: 2 },
    { name: "Dano de Contra Ataque", level: 2 },
    { name: "Redução de Dano de Contra Ataque", level: 2 },
    { name: "Capacidade dos mortos da primavera", level: 2 },

    { name: "Revival", level: 1 },
    { name: "Enfraquecer Revival", level: 1 },
    { name: "Massacre", level: 1 },
    { name: "Enfraquecer Massacre", level: 1 },
    { name: "Quick recruit", level: 1 },
    { name: "Capacidade das tropas de cada elemento", level: 1 }
];

function loadAttributes() {
    const container = document.getElementById("attribute-list");
    container.innerHTML = "";
    ATTRIBUTES.forEach(attr => {
        const div = document.createElement("div");
        div.classList.add("attribute-item");
        div.textContent = `${attr.name} (Lv${attr.level})${attr.element ? " - " + attr.element : ""}`;
        div.onclick = () => div.classList.toggle("selected");
        container.appendChild(div);
    });
}

function saveBuild() {
    const name = document.getElementById("build-name").value.trim();
    if (!name) return alert("Digite um nome para a build.");
    const selected = [...document.querySelectorAll('.attribute-item.selected')]
        .map(div => div.textContent);
    const build = { name, attributes: selected };
    const builds = JSON.parse(localStorage.getItem("builds") || "[]");
    builds.push(build);
    localStorage.setItem("builds", JSON.stringify(builds));
    renderBuilds();
}

function renderBuilds() {
    const container = document.getElementById("saved-builds");
    const builds = JSON.parse(localStorage.getItem("builds") || "[]");
    container.innerHTML = "";
    builds.forEach((b, i) => {
        const block = document.createElement("div");
        block.classList.add("build-block");
        block.innerHTML = `
            <strong>${b.name}</strong><br>
            <small>${b.attributes.length} atributos</small>
            <ul>${b.attributes.map(a => `<li>${a}</li>`).join("")}</ul>
            <button onclick="deleteBuild(${i})">Excluir</button>
        `;
        container.appendChild(block);
    });
}

function deleteBuild(index) {
    const builds = JSON.parse(localStorage.getItem("builds") || "[]");
    builds.splice(index, 1);
    localStorage.setItem("builds", JSON.stringify(builds));
    renderBuilds();
}

window.onload = () => {
    loadAttributes();
    renderBuilds();
    document.getElementById("save-build").onclick = saveBuild;
};