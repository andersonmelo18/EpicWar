// js/App.js

/**
 * Módulo principal da aplicação, gerencia a navegação e a inicialização.
 */
const App = (() => {
    
    const views = {
        dashboard: document.getElementById('dashboard-view'),
        editor: document.getElementById('build-editor-view'),
        admin: document.getElementById('admin-view'),
        report: document.getElementById('report-view')
    };

    /**
     * Alterna a visualização principal da aplicação.
     * @param {string} viewId - ID da view a ser exibida (dashboard, editor, admin, report).
     */
    const showView = (viewId) => {
        Object.keys(views).forEach(key => {
            views[key].classList.add('hidden');
        });
        
        if (views[viewId]) {
            views[viewId].classList.remove('hidden');
        }
    };
    
    // --- Lógica do Dashboard ---
    
    const renderDashboard = () => {
        const builds = StorageService.loadAllBuilds();
        const listContainer = document.getElementById('builds-list');
        const noBuildsMessage = document.getElementById('no-builds-message');
        
        if (builds.length === 0) {
            listContainer.innerHTML = '';
            noBuildsMessage.classList.remove('hidden');
            return;
        }

        noBuildsMessage.classList.add('hidden');
        
        let html = builds.map(build => `
            <div class="bg-white p-5 rounded-xl shadow-lg border border-gray-200 hover:shadow-xl transition duration-300">
                <h3 class="text-xl font-bold text-indigo-600 mb-2">${build.name || 'Build Sem Nome'}</h3>
                <p class="text-sm text-gray-500 mb-3">Classe: ${build.class || 'N/A'} | Artefatos: ${build.artifacts.length}</p>
                
                <div class="flex justify-between items-center mt-4 border-t pt-3">
                    <button data-id="${build.id}" class="edit-build-btn text-sm text-indigo-600 hover:text-indigo-800 font-semibold">
                        Editar Build
                    </button>
                    <button data-id="${build.id}" class="delete-build-btn text-sm text-red-500 hover:text-red-700">
                        Excluir
                    </button>
                </div>
            </div>
        `).join('');

        listContainer.innerHTML = html;
        
        // Adiciona listeners para os botões do dashboard
        listContainer.querySelectorAll('.edit-build-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = parseInt(e.currentTarget.dataset.id);
                BuildController.loadBuildForEditing(id);
                showView('editor');
            });
        });
        
        listContainer.querySelectorAll('.delete-build-btn').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const id = parseInt(e.currentTarget.dataset.id);
                const buildName = StorageService.loadBuildById(id)?.name || 'esta build';
                if (confirm(`Tem certeza que deseja excluir a build "${buildName}"?`)) {
                    StorageService.deleteBuild(id);
                    renderDashboard(); // Recarrega o dashboard
                }
            });
        });
    };
    
    // --- Lógica de Importação (NOVA) ---

    /**
     * Verifica se a URL contém um payload de importação (Base64) e carrega a build.
     * @returns {boolean} True se a build foi importada e o editor foi exibido.
     */
    const checkURLForImport = () => {
        const hash = window.location.hash;
        if (hash.startsWith('#import=')) {
            try {
                const base64Payload = hash.substring('#import='.length);
                const jsonString = atob(base64Payload); // Decodifica Base64
                const importedBuild = JSON.parse(jsonString);

                // Define a build importada como a build atual no BuildController
                if (importedBuild) {
                    // Limpa o ID para garantir que seja salva como uma NOVA build
                    importedBuild.id = null; 
                    
                    BuildController.setImportedBuild(importedBuild); 
                    
                    showView('editor');
                    alert(`Build "${importedBuild.name || 'Sem Nome'}" carregada para edição. Salve-a para persistir!`);
                    
                    // Limpa o hash da URL para evitar recarga no refresh
                    window.history.replaceState(null, null, ' ');
                    return true;
                }
            } catch (error) {
                console.error("Erro ao importar build da URL:", error);
                alert("Erro ao carregar build. O link de importação é inválido.");
            }
        }
        return false;
    };
    
    // --- Lógica de Inicialização ---

    const init = () => {
        // 1. Inicializa o estado mestre (Mock data)
        AdminService.initializeMasterData();
        BuildController.loadDependencies(); // Carrega listas mestras para o controlador de build
        
        // 2. Tenta importar a build da URL
        const isImporting = checkURLForImport(); // <-- CHAMADA AQUI
        
        // 3. Configura a navegação principal
        document.getElementById('nav-dashboard').addEventListener('click', () => { showDashboard(); });
        document.getElementById('nav-admin').addEventListener('click', () => { showAdmin(); });
        document.getElementById('nav-new-char').addEventListener('click', () => { showEditor(); });

        // 4. Configura eventos do Build Editor
        document.getElementById('artifact-count').addEventListener('change', (e) => {
            BuildController.updateArtifactCount(parseInt(e.target.value));
        });
        document.getElementById('save-build-draft-btn').addEventListener('click', () => {
            BuildController.saveCurrentBuild(true);
        });
        document.getElementById('run-full-analysis-btn').addEventListener('click', () => {
            BuildController.generateFinalReport();
        });
        document.getElementById('clear-build-btn').addEventListener('click', () => {
            if (confirm("Você tem certeza que deseja limpar a build atual?")) {
                 BuildController.initializeNewBuild();
            }
        });
        
        // 5. Exibe a tela inicial (somente se não estiver importando)
        if (!isImporting) {
            showDashboard();
        }
    };
    
    // Funções de navegação exportadas
    const showDashboard = () => {
        renderDashboard();
        showView('dashboard');
    };
    
    const showAdmin = () => {
        AdminController.initAdminView();
        showView('admin');
    };
    
    const showEditor = () => {
        BuildController.initializeNewBuild();
        showView('editor');
    };

    // Inicializa a aplicação quando o DOM estiver pronto
    document.addEventListener('DOMContentLoaded', init);
    
    return {
        showView, 
        showDashboard 
    };
})();