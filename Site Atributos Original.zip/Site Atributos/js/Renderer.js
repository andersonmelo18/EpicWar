// js/Renderer.js

/**
 * Módulo para renderizar componentes de UI no DOM.
 */
const Renderer = (() => {
    const ELEMENTS_ICONS = {
        fogo: '🔥',
        gelo: '❄️',
        luz: '🌕',
        veneno: '☠️'
    };
    
    // --- Funções de Ajuda ---
    
    const getElementIcon = (element) => ELEMENTS_ICONS[element] || '❓';
    
    const getRarityBadge = (rarity) => {
        const colors = {
            SSR: 'bg-yellow-500', SS: 'bg-indigo-500', S: 'bg-green-500', A: 'bg-blue-500', B: 'bg-gray-500'
        };
        return `<span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${colors[rarity] || 'bg-gray-400'} text-white">${rarity}</span>`;
    };
    
    const getRemodelBadge = (remodel) => {
        const colors = {
            normal: 'text-gray-500', raro: 'text-blue-500', perfeito: 'text-green-500', epico: 'text-purple-500', lendario: 'text-yellow-600', mitico: 'text-red-600'
        };
        const capitalized = remodel.charAt(0).toUpperCase() + remodel.slice(1);
        return `<span class="text-xs font-semibold ${colors[remodel] || 'text-gray-400'}">${capitalized}</span>`;
    };

    // --- Renderização de Componentes Principais ---

    /**
     * Renderiza o card de um Artefato.
     */
    const renderArtifactCard = (artifact, charId) => {
        const elementSlots = ['fogo', 'gelo', 'luz', 'veneno'];
        
        // Use a posição (0-3) para vincular a gema ao slot correto
        const gemCards = elementSlots.map((element, index) => {
            const gem = artifact.gems[index];
            const hasGem = !!gem;
            const elementClass = `text-${element}`;
            
            let content;
            if (hasGem) {
                // Conteúdo se a gema existe
                const attributesHtml = gem.attributes.map(attr => {
                    const masterAttr = StorageService.loadMasterAttributes().find(a => a.id === attr.attribute_id);
                    const name = masterAttr ? masterAttr.name : 'Atributo Desconhecido';
                    return `<div class="flex justify-between items-center text-xs">
                                <span>${name}</span>
                                ${getRemodelBadge(attr.remodel)}
                            </div>`;
                }).join('');
                
                content = `
                    <div class="p-3">
                        <div class="flex justify-between items-center mb-1">
                            ${getRarityBadge(gem.rarity)}
                            <span class="text-sm font-medium text-gray-700">+${gem.plus_level}</span>
                        </div>
                        <div class="space-y-1 mt-2">
                            ${attributesHtml}
                        </div>
                    </div>
                `;
            } else {
                // Conteúdo se o slot está vazio
                content = `
                    <div class="text-center p-4 text-gray-400 hover:text-indigo-500 transition duration-150">
                        <span class="text-4xl">${getElementIcon(element)}</span>
                        <p class="text-xs mt-1">Adicionar Gema</p>
                    </div>
                `;
            }
            
            return `
                <div 
                    class="border-2 border-dashed rounded-lg cursor-pointer ${hasGem ? 'border-gray-200 hover:border-indigo-400 bg-white' : 'border-gray-300 hover:border-indigo-500 bg-gray-50'}"
                    data-char-id="${charId}"
                    data-artifact-id="${artifact.id}"
                    data-slot-index="${index}"
                    data-element="${element}"
                    data-action="edit-gem"
                >
                    <div class="p-2 border-b-2 ${elementClass} text-center font-bold text-sm">
                        ${getElementIcon(element)} ${element.toUpperCase()}
                    </div>
                    ${content}
                </div>
            `;
        }).join('');

        return `
            <div id="artifact-card-${artifact.id}" class="bg-white p-5 rounded-xl shadow-lg border border-gray-200">
                <div class="flex justify-between items-center mb-4 border-b pb-3">
                    <h4 class="text-lg font-semibold text-gray-700">Artefato ${artifact.position}: ${artifact.name || 'Sem Nome'}</h4>
                    <div class="flex items-center space-x-3">
                        <span class="text-sm font-medium text-gray-500">Nível: </span>
                        <input type="number" value="${artifact.level}" min="0" data-artifact-id="${artifact.id}" data-char-id="${charId}" data-field="level" class="w-16 text-center border rounded-md p-1 text-sm artifact-input">
                        <input type="text" value="${artifact.name}" data-artifact-id="${artifact.id}" data-char-id="${charId}" data-field="name" placeholder="Nome do Artefato" class="border rounded-md p-1 text-sm artifact-input w-36">
                    </div>
                </div>
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4" id="artifact-gems-${artifact.id}">
                    ${gemCards}
                </div>
            </div>
        `;
    };

    /**
     * Renderiza o Modal para Adicionar/Editar Gema.
     * (Detalhes da implementação no BuildController)
     */
    const renderGemModal = (artifact, slotIndex, gemData, masterAttributes) => {
        const element = AdminService.ELEMENTS[slotIndex];
        const isEdit = !!gemData;
        const rarityOptions = AdminService.REMODELS.map(r => `<option value="${r}" ${gemData && gemData.rarity === r.toUpperCase() ? 'selected' : ''}>${r.toUpperCase()}</option>`).join('');
        
        let attributesHtml = '';
        const numAttributes = gemData ? gemData.attributes.length : 1;
        
        // Função para gerar um bloco de seleção de atributo
        const generateAttributeSelect = (index, attr = {}) => {
            const currentAttr = masterAttributes.find(a => a.id === attr.attribute_id);
            const currentTier = currentAttr ? currentAttr.tier : 3;

            // Filtra atributos globais (null) ou que correspondam ao elemento da gema
            const filteredAttributes = masterAttributes.filter(a => 
                !a.default_element || a.default_element === element
            );
            
            const attributeOptions = filteredAttributes.map(a => `<option value="${a.id}" data-tier="${a.tier}" ${a.id === attr.attribute_id ? 'selected' : ''}>${a.name}</option>`).join('');

            const remodelOptions = AdminService.REMODELS.map(r => `<option value="${r}" ${attr.remodel === r ? 'selected' : ''}>${r.charAt(0).toUpperCase() + r.slice(1)}</option>`).join('');

            // Nota: No MVP, o Tier é fixo no nome do atributo, mas mantemos o select para futura flexibilidade
            const tierOptions = [1, 2, 3].map(t => `<option value="${t}" ${currentTier === t ? 'selected' : ''}>Lv${t}</option>`).join('');


            return `
                <div class="attribute-row p-3 border rounded-lg bg-gray-50 mb-3" data-attr-index="${index}">
                    <h5 class="font-semibold text-gray-700 mb-2">Atributo ${index + 1}</h5>
                    <div class="grid grid-cols-3 gap-2">
                        <div>
                            <label class="block text-xs font-medium text-gray-500">Tier</label>
                            <select class="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 text-sm attribute-tier" disabled>
                                ${tierOptions}
                            </select>
                        </div>
                        
                        <div class="col-span-2">
                            <label class="block text-xs font-medium text-gray-500">Atributo</label>
                            <select required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 text-sm attribute-id">
                                <option value="">Selecione um Atributo</option>
                                ${attributeOptions}
                            </select>
                        </div>
                    </div>
                    
                    <div class="mt-3">
                        <label class="block text-xs font-medium text-gray-500">Remodelação/Qualidade</label>
                        <select required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 text-sm attribute-remodel">
                            ${remodelOptions}
                        </select>
                    </div>
                    
                    ${index > 0 ? `<button type="button" class="mt-3 text-red-500 text-xs font-medium remove-attribute-btn">Remover</button>` : ''}
                </div>
            `;
        };

        // Preenche com dados existentes ou um slot vazio
        if (isEdit && gemData && gemData.attributes) {
            gemData.attributes.forEach((attr, index) => {
                attributesHtml += generateAttributeSelect(index, attr);
            });
        }
        if (!attributesHtml) {
             attributesHtml += generateAttributeSelect(0);
        }

        const modalHtml = `
            <div id="gem-edit-modal" class="fixed inset-0 bg-gray-900 bg-opacity-75 flex items-center justify-center z-50">
                <div class="bg-white rounded-xl shadow-2xl p-6 w-full max-w-lg">
                    <h3 class="text-2xl font-bold mb-4 ${`text-${element}`} border-b pb-2">
                        ${isEdit ? 'Editar' : 'Adicionar'} Gema ${getElementIcon(element)} - Slot ${element.toUpperCase()}
                    </h3>

                    <form id="gem-form" data-artifact-id="${artifact.id}" data-slot-index="${slotIndex}">
                        <div class="grid grid-cols-2 gap-4 mb-4">
                            <div>
                                <label for="gem-rarity" class="block text-sm font-medium text-gray-700">Raridade</label>
                                <select id="gem-rarity" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 border text-sm">
                                    ${rarityOptions}
                                </select>
                            </div>
                            <div>
                                <label for="gem-plus-level" class="block text-sm font-medium text-gray-700">Nível + (0 a 20)</label>
                                <input type="number" id="gem-plus-level" min="0" max="20" required value="${gemData ? gemData.plus_level : 0}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 border text-sm">
                            </div>
                        </div>

                        <h4 class="text-lg font-semibold mb-3 mt-4">Atributos Especiais (1 a 3)</h4>
                        <div id="attributes-container" class="max-h-60 overflow-y-auto hide-scrollbar p-1">
                            ${attributesHtml}
                        </div>
                        
                        <div class="flex justify-between items-center mt-4">
                            <button type="button" id="add-attribute-row-btn" class="text-indigo-600 hover:text-indigo-800 text-sm font-medium" ${numAttributes >= 3 ? 'disabled' : ''}>
                                + Adicionar Atributo (Max 3)
                            </button>
                            
                            <div class="flex space-x-3">
                                <button type="button" id="remove-gem-btn" class="text-red-500 hover:text-red-700 text-sm font-medium" ${isEdit ? '' : 'hidden'}>
                                    Remover Gema
                                </button>
                                <button type="button" id="close-gem-modal-btn" class="px-4 py-2 text-sm font-medium rounded-md text-gray-700 bg-gray-200 hover:bg-gray-300">
                                    Cancelar
                                </button>
                                <button type="submit" class="px-4 py-2 text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">
                                    Salvar Gema
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        `;
        
        document.getElementById('modals-container').innerHTML = modalHtml;
    };


    return {
        getElementIcon,
        getRarityBadge,
        getRemodelBadge,
        renderArtifactCard,
        renderGemModal,
        // ... (Outras funções de renderização, como do Admin, virão em outro arquivo)
    };
})();