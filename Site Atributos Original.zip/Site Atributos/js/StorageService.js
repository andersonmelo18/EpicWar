// js/StorageService.js

/**
 * Módulo para gerenciar a persistência de dados no localStorage.
 * Simula o DB relacional de forma local.
 */
const StorageService = (() => {
    // Chaves fixas para o localStorage
    const STORAGE_KEYS = {
        BUILDS: 'PvPBuilds_Characters',
        ATTRIBUTES: 'PvPBuilds_MasterAttributes',
        COMBOS: 'PvPBuilds_Combos'
    };

    // --- Funções de Ajuda Geral ---
    const loadData = (key, defaultValue = '[]') => {
        const data = localStorage.getItem(key);
        return JSON.parse(data || defaultValue);
    };

    const saveData = (key, data) => {
        localStorage.setItem(key, JSON.stringify(data));
    };

    // --- BUILDs (Personagens) ---

    const loadAllBuilds = () => loadData(STORAGE_KEYS.BUILDS);
    
    const saveBuild = (buildData) => {
        let builds = loadAllBuilds();
        
        if (!buildData.id) {
            // Nova Build: Atribuir um ID único simples
            const newId = builds.length ? Math.max(...builds.map(b => b.id || 0)) + 1 : 1;
            buildData.id = newId;
            builds.push(buildData);
        } else {
            // Edição de Build existente
            const index = builds.findIndex(b => b.id === buildData.id);
            if (index !== -1) {
                builds[index] = buildData;
            } else {
                builds.push(buildData); // Caso o ID exista, mas não esteja na lista por algum erro
            }
        }
        
        saveData(STORAGE_KEYS.BUILDS, builds);
        return buildData;
    };

    const deleteBuild = (id) => {
        let builds = loadAllBuilds();
        builds = builds.filter(b => b.id !== id);
        saveData(STORAGE_KEYS.BUILDS, builds);
    };

    const loadBuildById = (id) => loadAllBuilds().find(b => b.id === id);


    // --- ATRIBUTOS (Listas Mestras) ---

    // Este será inicializado pelo AdminService na primeira carga
    const loadMasterAttributes = () => loadData(STORAGE_KEYS.ATTRIBUTES);
    const saveMasterAttributes = (attributes) => saveData(STORAGE_KEYS.ATTRIBUTES, attributes);
    
    // Simplificamos a lista de Obrigatórios para ser apenas parte do Master Attributes (required_pvp: boolean)
    const loadRequiredAttributes = () => loadMasterAttributes().filter(attr => attr.required_pvp === true);
    
    // --- COMBOS RECOMENDADOS ---
    
    const loadRecommendedCombos = () => loadData(STORAGE_KEYS.COMBOS);
    const saveRecommendedCombos = (combos) => saveData(STORAGE_KEYS.COMBOS, combos);

    return {
        loadAllBuilds,
        saveBuild,
        deleteBuild,
        loadBuildById,
        loadMasterAttributes,
        saveMasterAttributes,
        loadRequiredAttributes,
        loadRecommendedCombos,
        saveRecommendedCombos
    };
})();