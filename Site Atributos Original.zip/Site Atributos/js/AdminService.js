// js/AdminService.js

/**
 * Módulo para gerenciar a lógica de inicialização e CRUD dos dados mestres (Admin).
 */
const AdminService = (() => {
    // Constantes
    const ELEMENTS = ["fogo", "gelo", "luz", "veneno"];
    const REMODELS = ["normal", "raro", "perfeito", "epico", "lendario", "mitico"];

    // Dados de Atributos Mestres (Mock Data para iniciar o sistema)
    const MOCK_MASTER_ATTRIBUTES = [
        { id: 1, name: "Dano de Tropas (Lv3)", tier: 3, default_element: null, required_pvp: true, description: "Aumenta o dano base de todas as tropas." },
        { id: 2, name: "Tirano (Lv3)", tier: 3, default_element: "fogo", required_pvp: true, description: "Aumenta dano de tropas de Fogo e dano em PvP." },
        { id: 3, name: "Enfraquecer Tirano (Lv3)", tier: 3, default_element: "gelo", required_pvp: true, description: "Reduz o dano recebido de tropas de Fogo e concede resistência." },
        { id: 4, name: "HADEs (Lv3)", tier: 3, default_element: "luz", required_pvp: true, description: "Alta Aceleração de Dano em Elite e Tropa de Suporte." },
        { id: 5, name: "Resistência Mágica (Lv2)", tier: 2, default_element: null, required_pvp: true, description: "Aumenta a defesa contra dano mágico." },
        { id: 6, name: "HP Adicional (Lv1)", tier: 1, default_element: null, required_pvp: false, description: "Ponto de vida básico. Dispensável para PvP." },
    ];
    
    // Dados de Combos Recomendados (Mock Data)
    const MOCK_COMBOS = [
        { 
            id: 1, 
            name: "Offense A (Fogo/Gelo)", 
            description: "Combinação agressiva que exige Tirano e Enfraquecer.", 
            attribute_ids: [2, 3] 
        },
    ];

    /**
     * Inicializa os dados mestres (atributos e combos) se eles não existirem no localStorage.
     */
    const initializeMasterData = () => {
        let attributes = StorageService.loadMasterAttributes();
        if (attributes.length === 0) {
            StorageService.saveMasterAttributes(MOCK_MASTER_ATTRIBUTES);
            console.log("Dados mestres de Atributos inicializados.");
        }
        
        let combos = StorageService.loadRecommendedCombos();
        if (combos.length === 0) {
            StorageService.saveRecommendedCombos(MOCK_COMBOS);
            console.log("Dados mestres de Combos inicializados.");
        }
    };
    
    /**
     * Função CRUD: Adiciona ou Atualiza um Atributo.
     */
    const saveAttribute = (attributeData) => {
        let attributes = StorageService.loadMasterAttributes();
        
        if (attributeData.id) {
            // Atualizar
            const index = attributes.findIndex(a => a.id === attributeData.id);
            if (index !== -1) {
                attributes[index] = attributeData;
            }
        } else {
            // Novo
            const newId = attributes.length ? Math.max(...attributes.map(a => a.id || 0)) + 1 : 1;
            attributeData.id = newId;
            attributes.push(attributeData);
        }
        
        StorageService.saveMasterAttributes(attributes);
        return attributeData;
    };
    
    /**
     * Função CRUD: Deleta um Atributo.
     */
    const deleteAttribute = (id) => {
        let attributes = StorageService.loadMasterAttributes();
        attributes = attributes.filter(a => a.id !== id);
        StorageService.saveMasterAttributes(attributes);
    };

    return {
        ELEMENTS,
        REMODELS,
        initializeMasterData,
        saveAttribute,
        deleteAttribute
    };
})();