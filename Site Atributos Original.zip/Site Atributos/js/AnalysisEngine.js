// js/AnalysisEngine.js

/**
 * Módulo responsável por aplicar as regras de negócio PvP e gerar a análise.
 * NÃO TOCA NO DOM NEM NO localStorage diretamente.
 */
const AnalysisEngine = (() => {

    /**
     * Valida se a seleção de um atributo para uma gema é válida com base na exclusividade de elemento.
     * @param {number} attributeId - ID do atributo selecionado.
     * @param {string} gemElement - Elemento da gema (fogo, gelo, luz, veneno).
     * @param {Array} masterAttributes - Lista completa de atributos mestres.
     * @returns {boolean} True se válido, False se houver bloqueio.
     */
    const validateElementExclusivity = (attributeId, gemElement, masterAttributes) => {
        const attr = masterAttributes.find(a => a.id === attributeId);
        
        if (!attr || !attr.default_element) {
            // Atributo global ou não encontrado: sempre permitido.
            return true;
        }
        
        // Bloqueio: Atributo exclusivo selecionado em gema de elemento errado.
        return attr.default_element === gemElement;
    };
    
    /**
     * Executa a análise completa da build do personagem.
     * @param {object} characterBuild - O objeto JSON da build (personagem e artefatos).
     * @param {Array} masterAttributes - Lista de atributos mestres.
     * @param {Array} requiredAttributes - Lista de atributos obrigatórios PvP.
     * @param {Array} recommendedCombos - Lista de combos recomendados.
     * @returns {object} O objeto de análise contendo status, faltantes, inúteis, etc.
     */
    const runAnalysis = (characterBuild, masterAttributes, requiredAttributes, recommendedCombos) => {
        
        const requiredIds = new Set(requiredAttributes.map(a => a.id));
        const analysisResult = {
            present_attributes: new Map(), // Map<Attribute ID, Array<Location>>
            missing_attributes: [],
            dispensable_gems: [],
            invalid_placements: [],
            combo_status: []
        };
        
        const allPresentIds = new Set();
        
        // 1. ITERAR SOBRE ARTEFATOS E GEMAS
        characterBuild.artifacts.forEach((artifact, aIndex) => {
            if (!artifact) return;
            
            artifact.gems.forEach((gem, gIndex) => {
                if (!gem) return;
                
                const gemElement = AdminService.ELEMENTS[gIndex];
                let gemHasRequired = false;
                
                if (gem.attributes && gem.attributes.length > 0) {
                    
                    gem.attributes.forEach(gemAttr => {
                        const attrId = gemAttr.attribute_id;
                        const masterAttr = masterAttributes.find(a => a.id === attrId);
                        
                        if (!masterAttr) return; // Ignorar atributos desconhecidos/corrompidos
                        
                        const location = {
                            artifact_name: artifact.name || `Artefato ${artifact.position}`,
                            element: gemElement,
                            rarity: gem.rarity,
                            remodel: gemAttr.remodel,
                            position: `A${artifact.position}-${gemElement.toUpperCase().charAt(0)}`
                        };

                        // A) CHECAGEM DE EXCLUSIVIDADE (Auditoria, pois o Controller bloqueia)
                        if (!validateElementExclusivity(attrId, gemElement, masterAttributes)) {
                            analysisResult.invalid_placements.push({
                                attribute: masterAttr.name,
                                location: location
                            });
                            // Se inválido, não conta como presente.
                            return; 
                        }
                        
                        // B) CHECAGEM DE OBRIGATORIEDADE
                        if (requiredIds.has(attrId)) {
                            gemHasRequired = true;
                            allPresentIds.add(attrId);
                            
                            if (!analysisResult.present_attributes.has(attrId)) {
                                analysisResult.present_attributes.set(attrId, []);
                            }
                            // Adiciona a localização do atributo presente
                            analysisResult.present_attributes.get(attrId).push(location);
                        }
                    });
                }
                
                // C) CHECAGEM DE GEMA INÚTIL
                // Se a gema não possui NENHUM atributo da lista obrigatória
                if (!gemHasRequired) {
                    const hasAnyAttribute = gem.attributes && gem.attributes.length > 0;
                    
                    if (hasAnyAttribute) {
                        analysisResult.dispensable_gems.push({
                            element: gemElement,
                            location: {
                                artifact_name: artifact.name || `Artefato ${artifact.position}`,
                                position: `A${artifact.position}-${gemElement.toUpperCase().charAt(0)}`
                            },
                            reason: "Contém somente atributos dispensáveis (fora da lista PvP obrigatória)."
                        });
                    } else {
                         // Trata gema vazia como 'não existente' na análise inútil, 
                         // mas permite sugestão para este slot (se precisar de atributo faltante)
                    }
                }
            });
        });
        
        // 2. IDENTIFICAR ATRIBUTOS FALTANTES
        requiredAttributes.forEach(requiredAttr => {
            if (!allPresentIds.has(requiredAttr.id)) {
                // Atributo faltante: calcula onde ele PODE ir.
                const possibleSlots = AdminService.ELEMENTS.filter(element => 
                    !requiredAttr.default_element || requiredAttr.default_element === element
                );
                
                analysisResult.missing_attributes.push({
                    attribute: requiredAttr.name,
                    id: requiredAttr.id,
                    required_element: requiredAttr.default_element,
                    possible_elements: possibleSlots 
                });
            }
        });
        
        // 3. CHECAGEM DE COMBOS
        recommendedCombos.forEach(combo => {
            let presentCount = 0;
            combo.attribute_ids.forEach(attrId => {
                if (allPresentIds.has(attrId)) {
                    presentCount++;
                }
            });
            
            const completeness = (presentCount / combo.attribute_ids.length) * 100;
            
            if (completeness > 0) {
                analysisResult.combo_status.push({
                    name: combo.name,
                    completeness: completeness,
                    missing_items: combo.attribute_ids.filter(id => !allPresentIds.has(id))
                });
            }
        });
        
        return analysisResult;
    };

    // --- Funções para gerar a narrativa de saída (Relatório) ---

    /**
     * Gera uma sugestão narrativa para um atributo faltante.
     */
    const generateSuggestion = (missingAttr, characterBuild) => {
        const artifacts = characterBuild.artifacts.filter(a => !!a);
        
        // Encontrar o primeiro slot de gema VAZIO que aceite o atributo
        let bestSlot = null;
        
        for (const artifact of artifacts) {
            for (let i = 0; i < artifact.gems.length; i++) {
                const gem = artifact.gems[i];
                const element = AdminService.ELEMENTS[i];
                
                // 1. O slot aceita o atributo (por elemento)
                const elementMatches = !missingAttr.required_element || missingAttr.required_element === element;
                
                // 2. O slot está vazio ou contém uma Gema Inútil
                let isSlotAvailable = !gem; 
                if (!isSlotAvailable) {
                    // Checar se a gema é inútil (teria que re-rodar a análise ou checar se foi marcada)
                    // Para simplificar: Apenas slots vazios no MVP
                    // TODO: Implementar substituição de Gema Inútil.
                }

                if (elementMatches && isSlotAvailable) {
                    bestSlot = {
                        artifact_name: artifact.name || `Artefato ${artifact.position}`,
                        element: element,
                        position: `A${artifact.position}-${element.toUpperCase().charAt(0)}`
                    };
                    break;
                }
            }
            if (bestSlot) break;
        }

        if (bestSlot) {
            return `Considere adicionar **${missingAttr.attribute}** no slot **${bestSlot.position} (${bestSlot.element.charAt(0).toUpperCase() + bestSlot.element.slice(1)})**.`;
        } else {
            return `**${missingAttr.attribute}** - Nenhum slot vazio adequado encontrado. Sugestão: Substituir uma gema não essencial no elemento ${missingAttr.required_element || 'Global'}.`;
        }
    };
    
    // Funções de formatação e relatório final (detalhado) serão implementadas no BuildController

    return {
        validateElementExclusivity,
        runAnalysis,
        generateSuggestion
    };
})();