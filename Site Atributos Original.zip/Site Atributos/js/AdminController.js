// js/AdminController.js

/**
 * Controlador de eventos e renderização para o Painel Admin.
 */
const AdminController = (() => {
    
    // --- Funções de Renderização Específicas do Admin ---
    
    const renderAttributesTable = (attributes, container) => {
        let html = `
            <table class="min-w-full divide-y divide-gray-200">
                <thead>
                    <tr class="bg-gray-50">
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Nome</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tier</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Elemento Exclusivo</th>
                        <th class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase">Obrigatório PvP</th>
                        <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Ações</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
        `;

        attributes.forEach(attr => {
            const exclusiveElement = attr.default_element ? `<span class="capitalize font-semibold text-sm ${`text-${attr.default_element}`}">${attr.default_element}</span>` : 'Global';
            const requiredBadge = attr.required_pvp 
                ? '<span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">SIM</span>'
                : '<span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">NÃO</span>';
            
            html += `
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">${attr.name}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Lv${attr.tier}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${exclusiveElement}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-center">${requiredBadge}</td>
                    <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                        <button data-id="${attr.id}" class="edit-attribute-btn text-indigo-600 hover:text-indigo-900 mx-2">Editar</button>
                        <button data-id="${attr.id}" class="delete-attribute-btn text-red-600 hover:text-red-900">Excluir</button>
                    </td>
                </tr>
            `;
        });

        html += `</tbody></table>`;
        container.innerHTML = html;
    };
    
    // --- Renderização do Modal de Atributo ---
    
    const renderAttributeModal = (attr = {}) => {
        const isEdit = !!attr.id;
        const modalHtml = `
            <div id="attribute-modal" class="fixed inset-0 bg-gray-900 bg-opacity-75 flex items-center justify-center z-50">
                <div class="relative top-20 mx-auto p-5 border w-96 shadow-2xl rounded-md bg-white">
                    <h3 id="modal-title" class="text-lg font-bold mb-4">${isEdit ? 'Editar' : 'Novo'} Atributo</h3>
                    <form id="attribute-form">
                        <input type="hidden" id="attribute-id" value="${attr.id || ''}">
                        
                        <label for="name" class="block text-sm font-medium text-gray-700">Nome (Ex: Tirano (Lv3))</label>
                        <input type="text" id="name" required value="${attr.name || ''}" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 border mb-3">
                        
                        <label for="tier" class="block text-sm font-medium text-gray-700">Tier (Nível)</label>
                        <select id="tier" required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 border mb-3">
                            ${[1, 2, 3].map(t => `<option value="${t}" ${attr.tier === t ? 'selected' : ''}>Lv${t}</option>`).join('')}
                        </select>
                        
                        <label for="default_element" class="block text-sm font-medium text-gray-700">Elemento Exclusivo (Bloqueia outros)</label>
                        <select id="default_element" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 border mb-3">
                            <option value="" ${!attr.default_element ? 'selected' : ''}>Global (Nulo)</option>
                            ${AdminService.ELEMENTS.map(e => `<option value="${e}" ${attr.default_element === e ? 'selected' : ''}>${e.charAt(0).toUpperCase() + e.slice(1)}</option>`).join('')}
                        </select>

                        <div class="flex items-center mt-4 mb-4">
                            <input id="required_pvp" type="checkbox" ${attr.required_pvp ? 'checked' : ''} class="h-4 w-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500">
                            <label for="required_pvp" class="ml-2 block text-sm text-gray-900">Obrigatório para Builds PvP (Essencial)</label>
                        </div>

                        <label for="description" class="block text-sm font-medium text-gray-700">Descrição</label>
                        <textarea id="description" rows="2" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm p-2 border mb-4">${attr.description || ''}</textarea>

                        <div class="flex justify-end space-x-3">
                            <button type="button" id="close-attribute-modal-btn" class="px-4 py-2 text-sm font-medium rounded-md text-gray-700 bg-gray-200 hover:bg-gray-300">Cancelar</button>
                            <button type="submit" class="px-4 py-2 text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700">Salvar Atributo</button>
                        </div>
                    </form>
                </div>
            </div>
        `;
        document.getElementById('modals-container').innerHTML = modalHtml;
        document.getElementById('attribute-modal').classList.remove('hidden');
        
        // Adicionar listener de fechar
        document.getElementById('close-attribute-modal-btn').addEventListener('click', closeAttributeModal);
        // Adicionar listener de salvar
        document.getElementById('attribute-form').addEventListener('submit', handleSaveAttribute);
    };

    const closeAttributeModal = () => {
        document.getElementById('attribute-modal').remove();
    };

    // --- Lógica de Eventos ---

    const refreshAdminView = () => {
        const container = document.getElementById('attributes-table-container');
        if (!container) return; // A view admin pode estar oculta
        
        const masterAttributes = StorageService.loadMasterAttributes();
        renderAttributesTable(masterAttributes, container);
    };

    const handleSaveAttribute = (e) => {
        e.preventDefault();
        
        const form = e.target;
        const id = form.querySelector('#attribute-id').value;
        
        const attributeData = {
            id: id ? parseInt(id) : null,
            name: form.querySelector('#name').value,
            tier: parseInt(form.querySelector('#tier').value),
            default_element: form.querySelector('#default_element').value || null,
            required_pvp: form.querySelector('#required_pvp').checked,
            description: form.querySelector('#description').value
        };

        AdminService.saveAttribute(attributeData);
        closeAttributeModal();
        refreshAdminView();
    };

    const handleDeleteAttribute = (id) => {
        if (confirm("Tem certeza que deseja deletar este atributo? Esta ação não pode ser desfeita.")) {
            AdminService.deleteAttribute(id);
            refreshAdminView();
        }
    };
    
    // --- Inicialização da View Admin ---
    
    const initAdminView = () => {
        // 1. Injetar a estrutura HTML base do painel admin
        const adminView = document.getElementById('admin-view');
        adminView.innerHTML = `
            <h2 class="text-3xl font-bold mb-6 text-gray-800">🛠️ Painel de Administração</h2>
            <div class="border-b border-gray-200">
                <nav class="-mb-px flex space-x-8" id="admin-tabs">
                    <button data-tab="attributes" class="py-2 px-4 border-b-2 font-medium text-sm focus:outline-none border-indigo-500 text-indigo-600">
                        Atributos Mestres
                    </button>
                    <button data-tab="combos" class="py-2 px-4 border-b-2 font-medium text-sm focus:outline-none border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700">
                        Combos Recomendados (WIP)
                    </button>
                </nav>
            </div>

            <div id="attributes-content" class="mt-6">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-xl font-semibold">Gerenciar Atributos (Master List)</h3>
                    <button id="add-attribute-btn" class="bg-indigo-600 text-white px-4 py-2 rounded-lg hover:bg-indigo-700 transition duration-150 shadow-md">
                        + Novo Atributo
                    </button>
                </div>
                <div id="attributes-table-container" class="bg-white p-4 rounded-xl shadow-lg border border-gray-200">
                    </div>
            </div>
            
            <div id="combos-content" class="mt-6 hidden">
                <p class="text-gray-600">O gerenciamento de Combos Recomendados será adicionado aqui, utilizando os IDs dos Atributos Mestres.</p>
            </div>
        `;
        
        // 2. Renderizar a tabela inicial
        refreshAdminView();
        
        // 3. Adicionar Listeners de Evento
        document.getElementById('add-attribute-btn').addEventListener('click', () => renderAttributeModal({}));
        
        // Delegação de eventos para Editar/Deletar na tabela
        document.getElementById('attributes-table-container').addEventListener('click', (e) => {
            const editBtn = e.target.closest('.edit-attribute-btn');
            const deleteBtn = e.target.closest('.delete-attribute-btn');
            
            if (editBtn) {
                const id = parseInt(editBtn.dataset.id);
                const attr = StorageService.loadMasterAttributes().find(a => a.id === id);
                renderAttributeModal(attr);
            } else if (deleteBtn) {
                const id = parseInt(deleteBtn.dataset.id);
                handleDeleteAttribute(id);
            }
        });
    };

    return {
        initAdminView,
        refreshAdminView // Útil para ser chamado externamente (ex: depois de importar dados)
    };
})();